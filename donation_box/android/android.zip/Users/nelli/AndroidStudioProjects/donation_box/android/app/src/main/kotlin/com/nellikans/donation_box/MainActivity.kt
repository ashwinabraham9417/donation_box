package com.nellikans.donation_box

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
